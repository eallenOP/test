---
layout: page
title: What can I do?
---

## {{ page.title }}
![glass recycling bin](../img/bluebin.jpg)
If you don't already, you should be using [Blue bins](https://www.dunedin.govt.nz/services/rubbish-and-recycling/blue-recycling-bin) and [Yellow wheelie bins](https://www.dunedin.govt.nz/services/rubbish-and-recycling/yellow-lidded-wheelie-bins), and be putting them out for [Kerbside collection](https://www.dunedin.govt.nz/services/rubbish-and-recycling/collection-days) on the designated days for your area.
You should also use a [LoveNZ public recycling bin](https://www.dunedin.govt.nz/services/rubbish-and-recycling/public-place-recycling-stations) when possible and make sure to correctly deposit the types of rubbish into their respective bins.
When you buy a new electronic device, ask the supplier if they will take your old electronic device for recycling. Some distributors are starting to realise this is an add-on service they can offer customers.
Consumers can create the demand for recycling through their purchasing decisions, and place the responsibility for recycling on the producers where it belongs.

### References
- [DCC E-waste](https://www.dunedin.govt.nz/services/rubbish-and-recycling/e-waste)
- [Kerb collection days](https://www.dunedin.govt.nz/services/rubbish-and-recycling/collection-days)
- [Yellow Lid Bins](https://www.dunedin.govt.nz/services/rubbish-and-recycling/yellow-lidded-wheelie-bins)
- [Glass Recycling Bins](https://www.dunedin.govt.nz/services/rubbish-and-recycling/blue-recycling-bin)