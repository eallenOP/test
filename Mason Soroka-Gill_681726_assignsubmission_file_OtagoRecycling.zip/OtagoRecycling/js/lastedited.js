document.getElementById("lastedited").innerHTML 
    = "Last modified: " + document.lastModified;