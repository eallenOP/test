No need for

```
bundle exec jekyll serve
```

just use
```
jekyll serve
```

