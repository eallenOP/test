# RecyclingOtago
Assesment 
OK here we go. I have created html page as home page and added the nav bar with 8 links. i will amend or increase as I go through. The I have created the nav bar on all 8 pages i will have for my recycling website. The pages I will have are,
1 - Home
2 - About Us
3 - Recycling/Transfer Stations
4 - Landfill Charges & Prices
5 - Order Wheelie Bins
6 - Littering & Illegal Dumping
7 - e-Waste
8 - Contact Us
9 - Quiz

Added footer to all pages. at tis stage I am keeping simple footer with my details as I am creating this website. Then I have added he last modified tab just under the nav bar with the help of https://www.w3schools.com and aligned it to the right. I have a problem with the date and time as its reading the current time. It should display older time.

After speaking to Elise about the date issue above she dvised it is ok to display the current date and time for the last modified as its internal part but it will work if it was loaded on to the web servers. I have uploaded and main header back image from my learning I did for my website. Added few features in the text alignment. I have also added back image in h1 but need to alighn the pic properly as its not showing the whole pic. If i adjust the height it makes it too big. checking on internet. 
https://www.w3schools.com/cssref/css3_pr_background-size.asp


