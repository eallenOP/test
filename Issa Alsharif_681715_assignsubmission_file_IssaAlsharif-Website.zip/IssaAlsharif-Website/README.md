# WebAssignment
Client-side Web Development

Navigation Bar belongs to:
Simple Responsive Animated Flexbox Navigation
A PEN BY Julio
@codepen.io


Parrallax Effect from:
https://www.youtube.com/watch?v=JttTcnidSdQ
Basic Parallax Website With HTML & CSS
Traversy Media


https://www.youtube.com/watch?v=ZQhR5RbJ2sk&list=PL4cUxeGkcC9iGYgmEd2dm3zAKzyCGDtM5&index=12
CSS Animation Tutorial 
The Net Ninja


How to make footer with the help html and css use to font awesome
https://www.youtube.com/watch?v=tmEXwn04TYU&t=15s
Learning Tutorial Point

More references and comments are included within the HTML & CSS files.