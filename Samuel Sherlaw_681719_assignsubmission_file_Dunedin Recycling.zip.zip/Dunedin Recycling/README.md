# lab-checkpoints-Minisamuel
lab-checkpoints-Minisamuel created by GitHub Classroom

Hello My name is Samuel. In my free time i like to play games and also create them as well. My strongest erea in IT is coding and web development. i have done the level 4 cirtificate web so i have done a a good amount of web development. 

For the last few steps i got tripped up on the murging the branches together. The cloning went well after i found out how to do it. I think that doing the task on github worked really well and it made it easy to commit my work. I think that next time i will use a program outside of github and learn how to use that. 

I didn't have any difficultys while doing this task. I used h1 and h2 for differnt heading sizes. i choose to do this so that you could tell between smaller header the the main header.

The margin put a gap inbetween the padding background. This is because the margin doesnt keep the background colour.

In the table i added a margin and padding so that the words and pictures fit the table cells.

lab 1-6
After my 1-6 commit i made a mistake and made a new bruch on my local computer. But when i did this my local git wasn't up to
date with the online files. So i had to murage my master back into my demo-page brunch.

Design chooses:
Design:
For my website i have gone with a simple design much like the design of w3schools. My design has a long header up the top. An Aside
for my nav bar that is floated to the left. i have all my text/tables and list in the main box. This is to the right of my aside.
Under my aside and main i have a footer with my name in it.

Semantic:
i think that my code is very easy to read. This is because i have used the indentaion properly. I have also made sure that my text doesnt
scroll of the screen to far. I think how i have used tags like Header, aside, main, and footer make it also esay to find the content you
want to find.

style sheet:
in my style sheet i have made sure that i have put the main things like body, header, main, aside and footer at the top and things like
the table further down.

Lab 2.3:
During trying to learn how to use frameworks i found that alot of them had way to many lines of code. So i was spending alot of my time
trying to find a small but useful framework. I found a framework called simple grid. This one is a simple straight forward styles that
makes the text and headings and tables change.

During making my webpage i was using a vertical nav var for my link to down the page. After a while of doing this i have made the desission
to make my nav bar to a horazontal nav bar. This is because i felt like this made my page look more moden designed. 

checkpoint 2:
1: My navagation is easy to use because it is very well highlighted at the top of the page. i put my navagation with the homepage at the start
and the second page next and the last page last. this makes it so that the homepage is the main focus and the others are the side pages with further
information. 

2: I made all my code from scratch. I find frameworks messy and hard to work with. This probably made my work load alot more then if i used a framework
or exiting code. But that is just the way i enjoy making websites. I dont like restring myself to a framework.

3:
    3.1: Color: For my website colors i decided to go with plan and simple color screams. This is beacuse i didn't want the website to be too blown up with
    fancy colors. If i had done that it would of made my website hard to read/look at.

    3.2: Button: I decided to add a "back to the top button". This is because if you start to get really long pages it makes it easy for the user to go to the
    top of the page again.

4: 
    4.1: https://www.w3schools.com/

    4.2: https://learn.shayhowe.com/advanced-html-css/responsive-web-design/

    4.3: https://internetingishard.com/html-and-css/responsive-design/

Development Assigment Week 11
day 1: Looking at design elements so that for our assigment so our websites don't look behind 2009. 

day 2: Made a basic layout for my website and made my links work.

day 3: Getting started on the content for the pages. i am choosing to go with basic colors to start with so that i can focus on building the website before
       i spend time trying to make the website look good. 
       I made a color change to my footer and header becuase i have choosen my colour for the website. I have also added the logo into the header next to the links.

While doing raido buttons i have found that they don't seem to be working as proper radio buttons and i don't understand why that they aren't.
Also i can't java script!